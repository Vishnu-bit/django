Since Git doesn't support empty directories we have to precreate this directory for static files
