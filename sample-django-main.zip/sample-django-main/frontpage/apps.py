from django.apps import AppConfig


class FrontpageConfig(AppConfig):
    name = 'frontpage'
